To use the AutoHotkey library, you should copy `interception.dll` into this folder from `library\x64` in the Interception zip  
YOU MAY ALSO NEED TO RUN UNBLOCKER.PS1 AS ADMIN!!
